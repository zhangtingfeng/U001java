package com.jfc.base;

public class OrderProduct {
    private String id;
    private String product_id;
    private String productname;
    private String product_num;
    private String statusname;
    private String p_pay_money;
    private String p_order_money;
    private String shop_name;
    private String property;
    private String pnumber;
    private String pic;
    private String shop_id;
    private String packPrice;
    private String properties;
    private String printcode_two;

    public String getProperties() {
        return properties;
    }

    public void setProperties(String properties) {
        this.properties = properties;
    }

    public String getPackPrice() {
        return packPrice;
    }

    public void setPackPrice(String packPrice) {
        this.packPrice = packPrice;
    }

    public String getShop_id() {
        return shop_id;
    }

    public void setShop_id(String shop_id) {
        this.shop_id = shop_id;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getProduct_num() {
        return product_num;
    }

    public void setProduct_num(String product_num) {
        this.product_num = product_num;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getStatusname() {
        return statusname;
    }

    public void setStatusname(String statusname) {
        this.statusname = statusname;
    }

    public String getP_pay_money() {
        return p_pay_money;
    }

    public void setP_pay_money(String p_pay_money) {
        this.p_pay_money = p_pay_money;
    }

    public String getP_order_money() {
        return p_order_money;
    }

    public void setP_order_money(String p_order_money) {
        this.p_order_money = p_order_money;
    }

    public String getShop_name() {
        return shop_name;
    }

    public void setShop_name(String shop_name) {
        this.shop_name = shop_name;
    }

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public String getPnumber() {
        return pnumber;
    }

    public void setPnumber(String pnumber) {
        this.pnumber = pnumber;
    }

    public String getPrintcode_two() {
        return printcode_two;
    }

    public void setPrintcode_two(String printcode_two) {
        this.printcode_two = printcode_two;
    }
}
