package com.jfc.mapper;

public interface recharges {

}
