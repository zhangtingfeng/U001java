package com.jfc.base;

import java.util.List;

public class SpecsList {
    private String specs_id;
    private String val_id;
    private String val_name;
    private String shop_id;

    public String getSpecs_id() {
        return specs_id;
    }

    public void setSpecs_id(String specs_id) {
        this.specs_id = specs_id;
    }

    public String getVal_id() {
        return val_id;
    }

    public void setVal_id(String val_id) {
        this.val_id = val_id;
    }

    public String getVal_name() {
        return val_name;
    }

    public void setVal_name(String val_name) {
        this.val_name = val_name;
    }

    public String getShop_id() {
        return shop_id;
    }

    public void setShop_id(String shop_id) {
        this.shop_id = shop_id;
    }
}
