package com.jfc.base;

public class AdvanceProductList {
    private String id;
    private String name;
    private String smallpic;
    private String spic;
    private String shop_id;
    private String introduction;
    private String describes;
    private String prices_pay;
    private String product_tags;
    private String store;
    private String bmoney;
    private String mmoney;
    private String smoney;
    private String quota;
    private String type_id;
    private String bigpic;
    private String properties;

    public String getProperties() {
        return properties;
    }

    public void setProperties(String properties) {
        this.properties = properties;
    }

    public String getBigpic() {
        return bigpic;
    }

    public void setBigpic(String bigpic) {
        this.bigpic = bigpic;
    }

    public String getType_id() {
        return type_id;
    }

    public void setType_id(String type_id) {
        this.type_id = type_id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSmallpic() {
        return smallpic;
    }

    public void setSmallpic(String smallpic) {
        this.smallpic = smallpic;
    }

    public String getSpic() {
        return spic;
    }

    public void setSpic(String spic) {
        this.spic = spic;
    }

    public String getShop_id() {
        return shop_id;
    }

    public void setShop_id(String shop_id) {
        this.shop_id = shop_id;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getDescribes() {
        return describes;
    }

    public void setDescribes(String describes) {
        this.describes = describes;
    }

    public String getPrices_pay() {
        return prices_pay;
    }

    public void setPrices_pay(String prices_pay) {
        this.prices_pay = prices_pay;
    }

    public String getProduct_tags() {
        return product_tags;
    }

    public void setProduct_tags(String product_tags) {
        this.product_tags = product_tags;
    }

    public String getStore() {
        return store;
    }

    public void setStore(String store) {
        this.store = store;
    }

    public String getBmoney() {
        return bmoney;
    }

    public void setBmoney(String bmoney) {
        this.bmoney = bmoney;
    }

    public String getMmoney() {
        return mmoney;
    }

    public void setMmoney(String mmoney) {
        this.mmoney = mmoney;
    }

    public String getSmoney() {
        return smoney;
    }

    public void setSmoney(String smoney) {
        this.smoney = smoney;
    }

    public String getQuota() {
        return quota;
    }

    public void setQuota(String quota) {
        this.quota = quota;
    }
}
