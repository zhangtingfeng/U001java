import ask from "./sub/ask"
import answer from "./sub/answer"

export default {
	ask: ask,
	answer: answer
}

