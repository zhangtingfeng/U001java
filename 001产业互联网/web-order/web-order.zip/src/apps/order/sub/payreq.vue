<template>
    <div>
        <div :class='[curReadOnly?"box collapsed-box boxbackgroundcolor":"box boxbackgroundcolor"]'>
            <div class="box-header width-border  bg-lightgreen">
                <h3 class="box-title">付款申请</h3>
                <div class="box-tools pull-right">
                    <button type="button" class="btn btn-box-tool" data-widget="collapse">
                        <i :class='[curReadOnly?"fa fa-plus":"fa fa-minus"]'></i>
                    </button>
                </div>
            </div>

            <div v-if="!curReadOnly " class="box-body boxbody">
                <div class="row">
                   <!-- <div v-if="curgettpayment_request.id!=null &&curgettpayment_request.id!=''" class="col-md-3">
                        <p>申请单编号</p><span> {{curgettpayment_request.id}}</span>
                    </div>-->
                    <div class="col-md-3">
                        <label>申请单标题</label><span> <input type="text" class="form-control" name="curgettpayment_request.title"
                                                  v-model="curgettpayment_request.title"
                                                  placeholder="请输入申请单标题"/></span>
                    </div>

                    <div class="col-md-3">
                        <label>收款机构</label>
                        <select class="form-control" v-model="curgettpayment_request.receiptOrg">
                            <!--选择项的value值默认选择项文本 可动态绑定选择项的value值 更改v-model指令绑定数据-->
                            <option v-for="item in accountList" :value="item.id">{{item.rltAcc}}</option>
                        </select>



                    </div>
                    <div class="col-md-3">
                        <label>收款账户</label><span><input type="text" class="form-control"
                                                name="curgettpayment_request.receiptAccount"
                                                v-model="curgettpayment_request.receiptAccount"
                                                placeholder="请输入收款账户"/></span>
                    </div>
                    <div class="col-md-3">
                        <label>收款银行</label><span><input type="text" class="form-control"
                                                name="curgettpayment_request.receiptBank"
                                                v-model="curgettpayment_request.receiptBank"
                                                placeholder="请输入收款银行"/></span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-3">
                        <label>付款金额</label><span><input type="number" class="form-control" name="curgettpayment_request.amount"
                                                v-model="curgettpayment_request.amount" placeholder="请输入付款金额"/></span>
                    </div>

                   <!-- <div class="col-md-3">
                        <p>申请单状态</p><span> {{curgettpayment_request.status}}</span>
                    </div>-->
                </div>

                <button @click="save()" class="btn btn-primary"
                        style="float: right; margin-right:2%;width:6%;"
                        type="button">保存
                </button>

                <button @click="saveSunmit()" class="btn btn-primary"
                        style="float: right; margin-right:2%;width:6%;"
                        type="button">提交
                </button>
            </div>
            <div v-if="curReadOnly && curgettpayment_request" class="box-body boxbody">
                <div class="row">
                    <div class="col-md-3">
                        <label>申请单编号</label>
                        <span class="form-control">{{curgettpayment_request.id}}</span>
                    </div>
                    <div class="col-md-3">
                        <label>申请单标题</label>
                        <span class="form-control">{{curgettpayment_request.title}}</span>
                    </div>

                    <div class="col-md-3">
                        <label>收款机构</label>
                        <span class="form-control">{{curgettpayment_request.receiptOrg}}</span>
                    </div>
                    <div class="col-md-3">
                        <label>收款账户</label>
                        <span class="form-control">{{curgettpayment_request.receiptAccount}}</span>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-3">
                        <label>付款金额</label>
                        <span class="form-control">{{curgettpayment_request.amount}}</span>
                    </div>
                    <div class="col-md-3">
                        <label>收款银行</label>
                        <span class="form-control">{{curgettpayment_request.receiptBank}}</span>
                    </div>
                    <div class="col-md-3">
                        <label>申请单状态</label><span class="form-control"> {{curgettpayment_request.status}}</span>
                    </div>
                </div>
            </div>

        </div>


    </div>
</template>

<script>
    import {ajax, msg, progress} from "@f/vendor";
    import {comps, dict, editors} from "@f/framework";
    import pubFuncton from "../../pubcommon";
    export default {
        components: {
            date: editors.get("date")
        },
        data() {
            return {
                total: 0,
                order: this.orderFulldetail.order,
                curgettpayment_request: {},
                curReadOnly: this.readonly,
                selerdealer:{},
                accountList: []
            }
        },
        props: ["view", "id", "readonly", "args", "base", "orderFulldetail"],
        async beforeMount() {
            //debugger;
            let curgettpayment_requestList = this.orderFulldetail.payment_requestList;
//this.curReadOnly=!this.curReadOnly;
            let letCheckGet = false;
            let curargs = this.args;
            // curargs=2;

            for (let i = 0; i < curgettpayment_requestList.length; i++) {
                if (curgettpayment_requestList[i].payPhase == curargs && curargs != null) {
                    this.curgettpayment_request = curgettpayment_requestList[i];
                    letCheckGet = true;
                    break;
                }
            }
            if (letCheckGet == false) {////都找不到，那就是新搞一个
                this.curgettpayment_request.payPhase = curargs;

                this.curgettpayment_request.receiptOrg = this.selerdealer.bankTitle;///收款机构  请输入开户银行（买方）
                this.curgettpayment_request.receiptAccount = this.selerdealer.bankAccount;///收款账户
                this.curgettpayment_request.receiptBank = this.selerdealer.bank;///收款银行
            }
            /*申请单状态:1 申请 2 已审核 3 已支付 已支付*/
            if (this.curgettpayment_request.processId ||this.curgettpayment_request.status==3 ) {
                this.curReadOnly = true;
            }
            this.getselerdealer();

            //debugger;
            if (this.curReadOnly && letCheckGet) {

                this.curgettpayment_request.receiptOrg = await pubFuncton.getDescFunction(_this.curgettpayment_request.receiptOrg);
                debugger;
            } else {
                this.accountList = await pubFuncton.pubFuncton();
            }
            //debugger;


        },

        methods: {
            getselerdealer(){
                //await this.initpayment_request();
               // debugger;

                let letbuyerIdOrsellerId="";
                    letbuyerIdOrsellerId=this.orderFulldetail.order.sellerId;

                for(let i=0;i<this.orderFulldetail.dealers.length;i++){
                    if (letbuyerIdOrsellerId==this.orderFulldetail.dealers[i].orgId){
                        this.selerdealer=this.orderFulldetail.dealers[i];
                        break;
                    }
                }
            },

            saveSunmit() {
                this.curgettpayment_request.status = "0";
                this.save();
                location.reload();
            },

            save(argTypeInfo) {
                progress.show();
                //debugger; status: 1: 待支付, 0: 已支付
                if (this.curgettpayment_request.status != "0"){
                    this.curgettpayment_request.status = "1";
                }
                let _this=this;
                this.curgettpayment_request.orderId = this.id;

                //this.curgettpayment_request.payPhase = "0";
                ajax.post({
                    url: 'api/order/orderedit/savespayreq',
                    data: this.curgettpayment_request

                }).then(d => {
                    debugger;
                    console.log(d);
                    _this.curgettpayment_request=d.payreq;
                    msg.info("操作成功");
                    progress.hide();

                    // this.searchQuery();
                }).catch(d => {
                    debugger;
                    console.log(d);
                    msg.info(d.msg, "error");
                    progress.hide();
                });


            },


        }
    }
</script>

<style lang="less" scoped>
    @import url("@/common/common.less");
    .panel-body {
        .row {
            margin: 0 0 100px 0 !important;
        }

        p {
            font-weight: bold;
        }
    }

    .CSSBox {
        display: flex;
        flex-direction: row;
        -webkit-justify-content: space-between;
        justify-content: space-between;
    }

    .ButtonSave {
        align-items: flex-end;
    }


    .fade-enter-active,
    .fade-leave-active {
        transition: opacity .5s;
    }

    .fade-enter,
    .fade-leave-to
        /* .fade-leave-active below version 2.1.8 */ {
        opacity: 0;
    }
</style>
