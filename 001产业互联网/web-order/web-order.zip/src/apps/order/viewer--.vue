<template>
    <div>

        <goods-info v-model="orderGoods" v-if="orderGoods.length>0">
        </goods-info>
        <dealer-info :dealers="dealers" v-if="dealers.length>0"></dealer-info>
        <contract-info v-model="contract" v-if="contract!=null"></contract-info>

    </div>
</template>

<script>
    import {msg, ajax} from "@f/vendor";
    import Vue from "Vue";
    import FlowView from "./flowView";
    import GoodsInfo from "../SellerBuyerPub/goodsInfo";
    import DealerInfo from "../SellerBuyerPub/dealerInfo";
    import ContractInfo from "../SellerBuyerPub/contractinfo";
    import flowConfig from "../flow";

    export default {
        components: {FlowView, GoodsInfo, DealerInfo, ContractInfo},
        data() {
            return {
                btns: [],
                order: {},
                orderGoods: [],
                dealers: [],
                contract: null
            };
        },
        props: ["id", "base"],
        methods: {
            async initOrder() {
                try {
                    let data = await ajax.post({
                        url: "api/trade/info/getOrderDetail",
                        data: {orderId: this.id}
                    });

                    var i = 1;
                    for (var og of data.orderGoods) {
                        for (var g of data.goods) {
                            var props = [];
                            for (var p of data.props) {
                                if (g.id == p.listingSaleId) {
                                    props.push(p);
                                }
                            }
                            g.props = props;
                            for (var m in data.images) {
                                if (g.id == m && data.images[m].length > 0) {
                                    g.images = data.images[m];
                                    g.img = "api/trade/upload/" + g.images[0].path;
                                }
                            }
                            if (!g.images) {
                                g.img = "imgs/apples/pic_" + i + ".png";
                                if (i == 10) {
                                    i = 1;
                                } else {
                                    i++;
                                }
                            }
                            if (og.goodsId == g.id) {
                                og.goods = g;
                                og.total = og.num * g.unitPrice;
                            }
                        }
                    }

                    this.order = JSON.parse(data.order);
                    this.orderGoods = data.orderGoods;
                    this.orderGoods.modifier='sellerview';
                    this.dealers = data.dealers;
                    this.dealers.modifier = 'pubview';
                    this.contract = data.contract;
                    this.contract["specificationsList"] = data.specificationsList;
                    this.contract.modifier = 'pubview';
                    //debugger;
                } catch (err) {
                    msg.info("获取订单详情失败");
                }
            },
        },
        mounted() {
            this.initOrder();
        }
    };
</script>

<style lang="less" scoped>
    @import url("@/apps/common/common.less");

    .lr-padding {
        margin: auto 20px;
    }

    hr {
        border-color: @bg1;
    }

    .pay-box {
        margin-bottom: 20px;
    }

    .my-table {
        thead {
            background-color: @bg1;

            th {
                padding-top: 10px;
                padding-bottom: 10px;
            }
        }
    }
</style>
<style scoped>
    .add-address {
        text-align: center;
        margin: 24px 0;
    }

    .my-h1 {
        font-size: 16px;
    }

    .my-btn1 {
        color: #6abf4b;
        background-color: #ffffff;
        border-color: #6abf4b;
        width: 100px;
    }

    .my-btn2 {
        color: #333333;
        background-color: #ffffff;
        border-color: #e7e7e7;
        width: 100px;
    }

    .my-btn1 :focus {
        background-color: #6abf4b;
        border-color: #6abf4b;
    }

    .my-btn1 :hover {
        background-color: #6abf4b;
        border-color: #6abf4b;
    }

    .my-pay {
        margin: 0 40px;
    }

    .my-goods {
        font-size: 16px;
        margin: 3px 5px;
        padding: 5px 0;
    }

    .my-prop {
        margin: 0 5px;
    }

    .middle {
        vertical-align: middle;
    }

    .center {
        text-align: center;
    }

    .detail-edit {
        color: #6abf4b;
    }

    tfoot th {
        font-size: 20px;
        text-align: right;
    }

    tfoot th input {
        text-align: center;
        width: 150px;
    }

    button {
        margin: 0 15px;
    }
</style>
