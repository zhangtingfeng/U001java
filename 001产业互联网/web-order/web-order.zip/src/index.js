import { dict } from "@f/framework"

// 数据字典
dict.set("flowType", "api/order/flow-mng/types")

dict.set("flow-users", "api/order/flow-mng/flow-users")
