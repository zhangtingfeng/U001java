(window["webpackJsonp_name_"] = window["webpackJsonp_name_"] || []).push([["editors-district"],{

/***/ "./hs-libs/framework/ui/data/district.js":
/*!***********************************************!*\
  !*** ./hs-libs/framework/ui/data/district.js ***!
  \***********************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function($) {/* harmony import */ var core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _dict__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../dict */ "./hs-libs/framework/dict.js");


var proviences = [];
var datas = {};

function load() {
  var $d = $.Deferred();

  if (proviences.length) {
    $d.resolve(datas, proviences);
  } else {
    _dict__WEBPACK_IMPORTED_MODULE_1__["default"].getObjs("districts").then(function (data) {
      datas = data;

      for (var f in data) {
        var d = data[f];
        if (!f || !d) continue;
        var dist = f.substr(4, 2);
        var c = f.substr(2, 2);
        var p = f.substr(0, 2);

        if (c == "00" && dist == '00') {
          proviences.push(d);
        } else {
          if ("00" == dist) {
            var provience = data["".concat(p, "0000")];
            if (!provience.datas) provience.datas = [];
            provience.datas.push(d);
          } else {
            var city = data["".concat(p).concat(c, "00")];
            if (!city) continue;
            if (!city.datas) city.datas = [];
            city.datas.push(d);
          }
        }
      }

      $d.resolve(datas, proviences);
    }).fail(function (e) {
      $d.reject(e);
    });
  }

  return $d.promise();
}

/* harmony default export */ __webpack_exports__["default"] = ({
  load: load
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js")))

/***/ }),

/***/ "./hs-libs/framework/ui/editors/district.vue":
/*!***************************************************!*\
  !*** ./hs-libs/framework/ui/editors/district.vue ***!
  \***************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _district_vue_vue_type_template_id_39fd9e04_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./district.vue?vue&type=template&id=39fd9e04&scoped=true& */ "./hs-libs/framework/ui/editors/district.vue?vue&type=template&id=39fd9e04&scoped=true&");
/* harmony import */ var _district_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./district.vue?vue&type=script&lang=js& */ "./hs-libs/framework/ui/editors/district.vue?vue&type=script&lang=js&");
/* harmony import */ var _district_vue_vue_type_style_index_0_id_39fd9e04_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css& */ "./hs-libs/framework/ui/editors/district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _district_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _district_vue_vue_type_template_id_39fd9e04_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _district_vue_vue_type_template_id_39fd9e04_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "39fd9e04",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "hs-libs/framework/ui/editors/district.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./hs-libs/framework/ui/editors/district.vue?vue&type=script&lang=js&":
/*!****************************************************************************!*\
  !*** ./hs-libs/framework/ui/editors/district.vue?vue&type=script&lang=js& ***!
  \****************************************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_ref_0_1_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/babel-loader/lib??ref--0-1!../../../../node_modules/vue-loader/lib??vue-loader-options!./district.vue?vue&type=script&lang=js& */ "./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/district.vue?vue&type=script&lang=js&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_ref_0_1_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./hs-libs/framework/ui/editors/district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css&":
/*!************************************************************************************************************!*\
  !*** ./hs-libs/framework/ui/editors/district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css& ***!
  \************************************************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_style_index_0_id_39fd9e04_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib??vue-loader-options!./district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css&");
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_style_index_0_id_39fd9e04_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_style_index_0_id_39fd9e04_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_style_index_0_id_39fd9e04_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_style_index_0_id_39fd9e04_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_style_index_0_id_39fd9e04_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./hs-libs/framework/ui/editors/district.vue?vue&type=template&id=39fd9e04&scoped=true&":
/*!**********************************************************************************************!*\
  !*** ./hs-libs/framework/ui/editors/district.vue?vue&type=template&id=39fd9e04&scoped=true& ***!
  \**********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_template_id_39fd9e04_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib??vue-loader-options!./district.vue?vue&type=template&id=39fd9e04&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/district.vue?vue&type=template&id=39fd9e04&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_template_id_39fd9e04_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_district_vue_vue_type_template_id_39fd9e04_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css&":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/framework/ui/editors/district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css& ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".district[data-v-39fd9e04] {\n  display: flex;\n  flex-flow: row nowrap;\n}\n.district div[data-v-39fd9e04] {\n  min-width: 100px;\n  flex: 0 0 auto;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css&":
/*!***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/framework/ui/editors/district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css& ***!
  \***********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib??vue-loader-options!./district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/district.vue?vue&type=style&index=0&id=39fd9e04&scoped=true&lang=css&");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/district.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib??ref--0-1!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/framework/ui/editors/district.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _c_ui_Select2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @c/ui/Select2 */ "./hs-libs/components/ui/Select2.vue");
/* harmony import */ var _data_district__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../data/district */ "./hs-libs/framework/ui/data/district.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    select2: _c_ui_Select2__WEBPACK_IMPORTED_MODULE_0__["default"]
  },
  data: function data() {
    var provience = this.value ? this.value.substr(0, 2) + "0000" : "";
    var city = this.value ? this.value.substr(0, 4) + "00" : "";
    var district = this.value;
    return {
      datas: {},
      proviences: [],
      cities: [],
      districts: [],
      provience: provience,
      city: city,
      district: district,
      state: 0
    };
  },
  props: ["value", "readonly"],
  watch: {
    provience: function provience(val) {
      this.city = "";
      if (val) this.cities = this.datas[val].datas;
      this.district = "";
      this.districts = [];
    },
    city: function city(val) {
      this.district = "";
      if (val) this.districts = this.datas[val].datas;
    },
    district: function district(val) {
      this.$emit("input", val);
    }
  },
  methods: {
    load: function load() {
      var _this = this;

      var self = this;
      _data_district__WEBPACK_IMPORTED_MODULE_1__["default"].load().then(function (datas, proviences) {
        self.datas = datas;
        _this.proviences = proviences;

        if (_this.value) {
          _this.cities = datas[_this.provience].datas;
          _this.districts = datas[_this.city].datas;
        }

        _this.state = 1;
      }).fail(function (e) {
        _this.state = -1;
      });
    }
  },
  mounted: function mounted() {
    this.load();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/district.vue?vue&type=template&id=39fd9e04&scoped=true&":
/*!*********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/framework/ui/editors/district.vue?vue&type=template&id=39fd9e04&scoped=true& ***!
  \*********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "input-group" }, [
    _c(
      "div",
      { staticClass: "district" },
      [
        _vm.state == -1
          ? _c("span", [
              _vm._v("\n      " + _vm._s(_vm.$t("error.title")) + "\n    ")
            ])
          : _vm._e(),
        _vm._v(" "),
        _vm.state == 1
          ? [
              _c(
                "div",
                [
                  _c("select2", {
                    attrs: {
                      options: _vm.proviences,
                      readonly: _vm.readonly,
                      width: "100%",
                      hint: "省"
                    },
                    model: {
                      value: _vm.provience,
                      callback: function($$v) {
                        _vm.provience = $$v
                      },
                      expression: "provience"
                    }
                  })
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "div",
                [
                  _c("select2", {
                    attrs: {
                      options: _vm.cities,
                      readonly: _vm.readonly,
                      width: "100%",
                      hint: "市"
                    },
                    model: {
                      value: _vm.city,
                      callback: function($$v) {
                        _vm.city = $$v
                      },
                      expression: "city"
                    }
                  })
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "div",
                [
                  _c("select2", {
                    attrs: {
                      options: _vm.districts,
                      readonly: _vm.readonly,
                      width: "100%",
                      hint: "区"
                    },
                    model: {
                      value: _vm.district,
                      callback: function($$v) {
                        _vm.district = $$v
                      },
                      expression: "district"
                    }
                  })
                ],
                1
              )
            ]
          : _vm._e()
      ],
      2
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=editors-district.js.map