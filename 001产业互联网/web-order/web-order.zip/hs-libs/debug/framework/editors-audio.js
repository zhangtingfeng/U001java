(window["webpackJsonp_name_"] = window["webpackJsonp_name_"] || []).push([["editors-audio"],{

/***/ "./hs-libs/framework/ui/editors/audio.vue":
/*!************************************************!*\
  !*** ./hs-libs/framework/ui/editors/audio.vue ***!
  \************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _audio_vue_vue_type_template_id_584be150___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./audio.vue?vue&type=template&id=584be150& */ "./hs-libs/framework/ui/editors/audio.vue?vue&type=template&id=584be150&");
/* harmony import */ var _audio_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./audio.vue?vue&type=script&lang=js& */ "./hs-libs/framework/ui/editors/audio.vue?vue&type=script&lang=js&");
/* harmony import */ var _audio_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./audio.vue?vue&type=style&index=0&lang=css& */ "./hs-libs/framework/ui/editors/audio.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
/* harmony import */ var _audio_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./audio.vue?vue&type=custom&index=0&blockType=i18n-yaml */ "./hs-libs/framework/ui/editors/audio.vue?vue&type=custom&index=0&blockType=i18n-yaml");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _audio_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _audio_vue_vue_type_template_id_584be150___WEBPACK_IMPORTED_MODULE_0__["render"],
  _audio_vue_vue_type_template_id_584be150___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof _audio_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_4__["default"] === 'function') Object(_audio_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_4__["default"])(component)

/* hot reload */
if (false) { var api; }
component.options.__file = "hs-libs/framework/ui/editors/audio.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./hs-libs/framework/ui/editors/audio.vue?vue&type=custom&index=0&blockType=i18n-yaml":
/*!********************************************************************************************!*\
  !*** ./hs-libs/framework/ui/editors/audio.vue?vue&type=custom&index=0&blockType=i18n-yaml ***!
  \********************************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/@intlify/vue-i18n-loader/lib!../../../../node_modules/yaml-loader!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib??vue-loader-options!./audio.vue?vue&type=custom&index=0&blockType=i18n-yaml */ "./node_modules/@intlify/vue-i18n-loader/lib/index.js!./node_modules/yaml-loader/index.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/audio.vue?vue&type=custom&index=0&blockType=i18n-yaml");
/* harmony import */ var _node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./hs-libs/framework/ui/editors/audio.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./hs-libs/framework/ui/editors/audio.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_ref_0_1_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/babel-loader/lib??ref--0-1!../../../../node_modules/vue-loader/lib??vue-loader-options!./audio.vue?vue&type=script&lang=js& */ "./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/audio.vue?vue&type=script&lang=js&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_ref_0_1_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./hs-libs/framework/ui/editors/audio.vue?vue&type=style&index=0&lang=css&":
/*!*********************************************************************************!*\
  !*** ./hs-libs/framework/ui/editors/audio.vue?vue&type=style&index=0&lang=css& ***!
  \*********************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/style-loader/dist/cjs.js!../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib??vue-loader-options!./audio.vue?vue&type=style&index=0&lang=css& */ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/audio.vue?vue&type=style&index=0&lang=css&");
/* harmony import */ var _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_style_loader_dist_cjs_js_node_modules_css_loader_dist_cjs_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_node_modules_sass_loader_dist_cjs_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./hs-libs/framework/ui/editors/audio.vue?vue&type=template&id=584be150&":
/*!*******************************************************************************!*\
  !*** ./hs-libs/framework/ui/editors/audio.vue?vue&type=template&id=584be150& ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_template_id_584be150___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib??vue-loader-options!./audio.vue?vue&type=template&id=584be150& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/audio.vue?vue&type=template&id=584be150&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_template_id_584be150___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_audio_vue_vue_type_template_id_584be150___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/@intlify/vue-i18n-loader/lib/index.js!./node_modules/yaml-loader/index.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/audio.vue?vue&type=custom&index=0&blockType=i18n-yaml":
/*!**************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@intlify/vue-i18n-loader/lib!./node_modules/yaml-loader!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/framework/ui/editors/audio.vue?vue&type=custom&index=0&blockType=i18n-yaml ***!
  \**************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en":{"translate":"translate","tips":"Your browser does not support this audio play.","novoice":"No voice"},"cn":{"translate":"翻译","tips":"当前浏览器不支持在线播放","novoice":"没有录音文件"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/audio.vue?vue&type=style&index=0&lang=css&":
/*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/framework/ui/editors/audio.vue?vue&type=style&index=0&lang=css& ***!
  \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

// Imports
var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
exports = ___CSS_LOADER_API_IMPORT___(false);
// Module
exports.push([module.i, ".audio-style {\n  vertical-align: middle;\n}\n", ""]);
// Exports
module.exports = exports;


/***/ }),

/***/ "./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/audio.vue?vue&type=style&index=0&lang=css&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader/dist/cjs.js!./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/framework/ui/editors/audio.vue?vue&type=style&index=0&lang=css& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../../../node_modules/css-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../node_modules/postcss-loader/src!../../../../node_modules/sass-loader/dist/cjs.js!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib??vue-loader-options!./audio.vue?vue&type=style&index=0&lang=css& */ "./node_modules/css-loader/dist/cjs.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js!./node_modules/sass-loader/dist/cjs.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/audio.vue?vue&type=style&index=0&lang=css&");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);



module.exports = content.locals || {};

/***/ }),

/***/ "./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/audio.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib??ref--0-1!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/framework/ui/editors/audio.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _c_progress__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @c/progress */ "./hs-libs/components/progress.js");
/* harmony import */ var _c_msg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @c/msg */ "./hs-libs/components/msg.js");
/* harmony import */ var _c_ajax__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @c/ajax */ "./hs-libs/components/ajax.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      data: this.value
    };
  },
  props: ["value", "name"],
  watch: {
    data: function data(val) {
      this.$emit("input", val);
    }
  },
  methods: {
    translate: function translate(value, event) {
      var form = this.$parent.data.form;

      if (null == form.voicetext || undefined == form.voicetext) {
        _c_progress__WEBPACK_IMPORTED_MODULE_0__["default"].show();
        var promise = _c_ajax__WEBPACK_IMPORTED_MODULE_2__["default"].post({
          url: "api/incident/translate.json",
          data: {
            voiceurl: value,
            id: form.id
          }
        });
        promise.then(function (data) {
          form.voicetext = data.data; // 触发数据变更

          var temp = form.customername;
          form.customername = "-";
          form.customername = temp;
        }).catch(function (rs) {
          _c_msg__WEBPACK_IMPORTED_MODULE_1__["default"].info("servererror", "error");
        }).always(function () {
          _c_progress__WEBPACK_IMPORTED_MODULE_0__["default"].hide();
        });
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/framework/ui/editors/audio.vue?vue&type=template&id=584be150&":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/framework/ui/editors/audio.vue?vue&type=template&id=584be150& ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "form-group" }, [
    _vm.value
      ? _c(
          "button",
          {
            staticClass: "btn btn-primary",
            on: {
              click: function($event) {
                $event.preventDefault()
                return _vm.translate(_vm.value)
              }
            }
          },
          [_vm._v(_vm._s(_vm.$t("translate")))]
        )
      : _vm._e(),
    _vm._v(" "),
    _vm.value
      ? _c(
          "audio",
          {
            staticClass: "audio-style",
            attrs: { controls: "", name: _vm.name }
          },
          [
            _c("source", { attrs: { src: _vm.value, type: "audio/wav" } }),
            _vm._v(" "),
            _c("source", { attrs: { src: _vm.value, type: "audio/mpeg" } }),
            _vm._v(" "),
            _c("source", { attrs: { src: _vm.value, type: "audio/ogg" } }),
            _vm._v(" "),
            _c("embed", { attrs: { src: _vm.value } }),
            _vm._v("\n    " + _vm._s(_vm.$t("tips")) + "\n  ")
          ]
        )
      : _vm._e(),
    _vm._v(" "),
    !_vm.value ? _c("span", [_vm._v(_vm._s(_vm.$t("novoice")))]) : _vm._e()
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=editors-audio.js.map