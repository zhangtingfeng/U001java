(window["webpackJsonp_name_"] = window["webpackJsonp_name_"] || []).push([["comps-ChgLocale"],{

/***/ "./hs-libs/components/ui/ChgLocale.vue":
/*!*********************************************!*\
  !*** ./hs-libs/components/ui/ChgLocale.vue ***!
  \*********************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ChgLocale_vue_vue_type_template_id_5199507d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ChgLocale.vue?vue&type=template&id=5199507d& */ "./hs-libs/components/ui/ChgLocale.vue?vue&type=template&id=5199507d&");
/* harmony import */ var _ChgLocale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ChgLocale.vue?vue&type=script&lang=js& */ "./hs-libs/components/ui/ChgLocale.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");
/* harmony import */ var _ChgLocale_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ChgLocale.vue?vue&type=custom&index=0&blockType=i18n-yaml */ "./hs-libs/components/ui/ChgLocale.vue?vue&type=custom&index=0&blockType=i18n-yaml");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ChgLocale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ChgLocale_vue_vue_type_template_id_5199507d___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ChgLocale_vue_vue_type_template_id_5199507d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof _ChgLocale_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_3__["default"] === 'function') Object(_ChgLocale_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_3__["default"])(component)

/* hot reload */
if (false) { var api; }
component.options.__file = "hs-libs/components/ui/ChgLocale.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./hs-libs/components/ui/ChgLocale.vue?vue&type=custom&index=0&blockType=i18n-yaml":
/*!*****************************************************************************************!*\
  !*** ./hs-libs/components/ui/ChgLocale.vue?vue&type=custom&index=0&blockType=i18n-yaml ***!
  \*****************************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/@intlify/vue-i18n-loader/lib!../../../node_modules/yaml-loader!../../../node_modules/thread-loader/dist/cjs.js!../../../node_modules/vue-loader/lib??vue-loader-options!./ChgLocale.vue?vue&type=custom&index=0&blockType=i18n-yaml */ "./node_modules/@intlify/vue-i18n-loader/lib/index.js!./node_modules/yaml-loader/index.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/components/ui/ChgLocale.vue?vue&type=custom&index=0&blockType=i18n-yaml");
/* harmony import */ var _node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_intlify_vue_i18n_loader_lib_index_js_node_modules_yaml_loader_index_js_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_custom_index_0_blockType_i18n_yaml__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./hs-libs/components/ui/ChgLocale.vue?vue&type=script&lang=js&":
/*!**********************************************************************!*\
  !*** ./hs-libs/components/ui/ChgLocale.vue?vue&type=script&lang=js& ***!
  \**********************************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_ref_0_1_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/thread-loader/dist/cjs.js!../../../node_modules/babel-loader/lib??ref--0-1!../../../node_modules/vue-loader/lib??vue-loader-options!./ChgLocale.vue?vue&type=script&lang=js& */ "./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./hs-libs/components/ui/ChgLocale.vue?vue&type=script&lang=js&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_ref_0_1_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./hs-libs/components/ui/ChgLocale.vue?vue&type=template&id=5199507d&":
/*!****************************************************************************!*\
  !*** ./hs-libs/components/ui/ChgLocale.vue?vue&type=template&id=5199507d& ***!
  \****************************************************************************/
/*! exports provided: render, staticRenderFns */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_template_id_5199507d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/thread-loader/dist/cjs.js!../../../node_modules/vue-loader/lib??vue-loader-options!./ChgLocale.vue?vue&type=template&id=5199507d& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/components/ui/ChgLocale.vue?vue&type=template&id=5199507d&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_template_id_5199507d___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_ChgLocale_vue_vue_type_template_id_5199507d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/@intlify/vue-i18n-loader/lib/index.js!./node_modules/yaml-loader/index.js!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/components/ui/ChgLocale.vue?vue&type=custom&index=0&blockType=i18n-yaml":
/*!***********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/@intlify/vue-i18n-loader/lib!./node_modules/yaml-loader!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/components/ui/ChgLocale.vue?vue&type=custom&index=0&blockType=i18n-yaml ***!
  \***********************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/*! all exports used */
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en":{"name":"中文"},"cn":{"name":"English"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./hs-libs/components/ui/ChgLocale.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib??ref--0-1!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/components/ui/ChgLocale.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function($) {/* harmony import */ var _c_locale__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @c/locale */ "./hs-libs/components/locale/index.js");
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  methods: {
    updateTitle: function updateTitle() {
      $("title").html(this.$t("app.name"));
    },
    chg: function chg() {
      var l = "en" == _c_locale__WEBPACK_IMPORTED_MODULE_0__["default"].get() ? "cn" : "en";
      _c_locale__WEBPACK_IMPORTED_MODULE_0__["default"].set(l);
      this.updateTitle();
    }
  },
  mounted: function mounted() {
    this.updateTitle();
  }
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js")))

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/components/ui/ChgLocale.vue?vue&type=template&id=5199507d&":
/*!***************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/components/ui/ChgLocale.vue?vue&type=template&id=5199507d& ***!
  \***************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "a",
    {
      attrs: { href: "#" },
      on: {
        click: function($event) {
          $event.preventDefault()
          return _vm.chg()
        }
      }
    },
    [
      _c("i", { staticClass: "fa fa-globe" }),
      _vm._v(" "),
      _c("span", [_vm._v(_vm._s(_vm.$t("name")))])
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=comps-ChgLocale.js.map