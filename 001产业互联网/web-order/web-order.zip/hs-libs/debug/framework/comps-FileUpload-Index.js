(window["webpackJsonp_name_"] = window["webpackJsonp_name_"] || []).push([["comps-FileUpload-Index"],{

/***/ "./hs-libs/components/ui/FileUpload/Index.vue":
/*!****************************************************!*\
  !*** ./hs-libs/components/ui/FileUpload/Index.vue ***!
  \****************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Index_vue_vue_type_template_id_28427a22___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Index.vue?vue&type=template&id=28427a22& */ "./hs-libs/components/ui/FileUpload/Index.vue?vue&type=template&id=28427a22&");
/* harmony import */ var _Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Index.vue?vue&type=script&lang=js& */ "./hs-libs/components/ui/FileUpload/Index.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Index_vue_vue_type_template_id_28427a22___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Index_vue_vue_type_template_id_28427a22___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "hs-libs/components/ui/FileUpload/Index.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./hs-libs/components/ui/FileUpload/Index.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./hs-libs/components/ui/FileUpload/Index.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_ref_0_1_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/babel-loader/lib??ref--0-1!../../../../node_modules/vue-loader/lib??vue-loader-options!./Index.vue?vue&type=script&lang=js& */ "./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./hs-libs/components/ui/FileUpload/Index.vue?vue&type=script&lang=js&");
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_thread_loader_dist_cjs_js_node_modules_babel_loader_lib_index_js_ref_0_1_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./hs-libs/components/ui/FileUpload/Index.vue?vue&type=template&id=28427a22&":
/*!***********************************************************************************!*\
  !*** ./hs-libs/components/ui/FileUpload/Index.vue?vue&type=template&id=28427a22& ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_28427a22___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/thread-loader/dist/cjs.js!../../../../node_modules/vue-loader/lib??vue-loader-options!./Index.vue?vue&type=template&id=28427a22& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/components/ui/FileUpload/Index.vue?vue&type=template&id=28427a22&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_28427a22___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_thread_loader_dist_cjs_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Index_vue_vue_type_template_id_28427a22___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./hs-libs/components/ui/FileUpload/jquery.ajaxfileupload.js":
/*!*******************************************************************!*\
  !*** ./hs-libs/components/ui/FileUpload/jquery.ajaxfileupload.js ***!
  \*******************************************************************/
/*! no exports provided */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(jQuery) {/* harmony import */ var core_js_modules_es_array_join__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.join */ "./node_modules/core-js/modules/es.array.join.js");
/* harmony import */ var core_js_modules_es_array_join__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_regexp_exec__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.regexp.exec */ "./node_modules/core-js/modules/es.regexp.exec.js");
/* harmony import */ var core_js_modules_es_regexp_exec__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_string_split__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.string.split */ "./node_modules/core-js/modules/es.string.split.js");
/* harmony import */ var core_js_modules_es_string_split__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_split__WEBPACK_IMPORTED_MODULE_2__);




/*
// jQuery Ajax File Uploader
//
// @author: Jordan Feldstein <jfeldstein.com>
//
//  - Ajaxifies an individual <input type="file">
//  - Files are sandboxed. Doesn't matter how many, or where they are, on the page.
//  - Allows for extra parameters to be included with the file
//  - onStart callback can cancel the upload by returning false
*/
(function ($) {
  $.fn.ajaxfileupload = function (options) {
    var settings = {
      params: {},
      action: '',
      onStart: function onStart() {},
      onComplete: function onComplete(response) {},
      onCancel: function onCancel() {},
      validate_extensions: true,
      valid_extensions: ['gif', 'png', 'jpg', 'jpeg'],
      submit_button: null
    };
    var uploading_file = false;

    if (options) {
      $.extend(settings, options);
    } // 'this' is a jQuery collection of one or more (hopefully) 
    //  file elements, but doesn't check for this yet


    return this.each(function () {
      var $element = $(this); // Skip elements that are already setup. May replace this 
      //  with uninit() later, to allow updating that settings

      if ($element.data('ajaxUploader-setup') === true) return;
      $element.change(function () {
        // since a new image was selected, reset the marker
        uploading_file = false; // only update the file from here if we haven't assigned a submit button

        if (settings.submit_button == null) {
          upload_file();
        }
      });

      if (settings.submit_button == null) {// do nothing
      } else {
        settings.submit_button.click(function (e) {
          // Prevent non-AJAXy submit
          e.preventDefault(); // only attempt to upload file if we're not uploading

          if (!uploading_file) {
            upload_file();
          }
        });
      }

      var upload_file = function upload_file() {
        if ($element.val() == '') return settings.onCancel.apply($element, [settings.params]); // make sure extension is valid

        var ext = $element.val().split('.').pop().toLowerCase();

        if (true === settings.validate_extensions && $.inArray(ext, settings.valid_extensions) == -1) {
          // Pass back to the user
          settings.onComplete.apply($element, [{
            status: false,
            message: '选择的文件不合法. 文件的后缀必须是(' + settings.valid_extensions.join(', ') + ').'
          }, settings.params]);
        } else {
          uploading_file = true; // Creates the form, extra inputs and iframe used to 
          //  submit / upload the file

          wrapElement($element); // Call user-supplied (or default) onStart(), setting
          //  it's this context to the file DOM element

          var ret = settings.onStart.apply($element, [settings.params]); // let onStart have the option to cancel the upload

          if (ret !== false) {
            $element.parent('form').submit(function (e) {
              e.stopPropagation();
            }).submit();
          }
        }
      }; // Mark this element as setup


      $element.data('ajaxUploader-setup', true);
      /*
      // Internal handler that tries to parse the response 
      //  and clean up after ourselves. 
      */

      var handleResponse = function handleResponse(loadedFrame, element) {
        var response,
            responseStr = loadedFrame.contentWindow.document.body.innerHTML;

        try {
          response = JSON.parse(responseStr);
        } catch (e) {
          try {
            response = JSON.parse($(responseStr).html());
          } catch (e) {
            response = responseStr;
          }
        } // Tear-down the wrapper form


        element.siblings().remove();
        element.unwrap();
        $(loadedFrame).remove();
        uploading_file = false; // Pass back to the user

        settings.onComplete.apply(element, [response, settings.params]);
      };
      /*
      // Wraps element in a <form> tag, and inserts hidden inputs for each
      //  key:value pair in settings.params so they can be sent along with
      //  the upload. Then, creates an iframe that the whole thing is 
      //  uploaded through. 
      */


      var wrapElement = function wrapElement(element) {
        // Create an iframe to submit through, using a semi-unique ID
        var frame_id = 'ajaxUploader-iframe-' + Math.round(new Date().getTime() / 1000);
        $('body').after('<iframe width="0" height="0" style="display:none;" name="' + frame_id + '" id="' + frame_id + '"/>');
        $('#' + frame_id).on("load", function () {
          handleResponse(this, element);
        }); // Wrap it in a form

        element.wrap(function () {
          return '<form action="' + settings.action + '" method="POST" enctype="multipart/form-data" target="' + frame_id + '" />';
        }) // Insert <input type='hidden'>'s for each param
        .before(function () {
          var key,
              html = '';

          for (key in settings.params) {
            var paramVal = settings.params[key];

            if (typeof paramVal === 'function') {
              paramVal = paramVal();
            }

            html += '<input type="hidden" name="' + key + '" value="' + paramVal + '" />';
          }

          return html;
        });
      };
    });
  };
})(jQuery);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js")))

/***/ }),

/***/ "./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./hs-libs/components/ui/FileUpload/Index.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib??ref--0-1!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/components/ui/FileUpload/Index.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function($) {/* harmony import */ var core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.array.concat */ "./node_modules/core-js/modules/es.array.concat.js");
/* harmony import */ var core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_find__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.array.find */ "./node_modules/core-js/modules/es.array.find.js");
/* harmony import */ var core_js_modules_es_array_find__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.function.name */ "./node_modules/core-js/modules/es.function.name.js");
/* harmony import */ var core_js_modules_es_function_name__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jquery_ajaxfileupload__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./jquery.ajaxfileupload */ "./hs-libs/components/ui/FileUpload/jquery.ajaxfileupload.js");
/* harmony import */ var _c_progress__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @c/progress */ "./hs-libs/components/progress.js");
/* harmony import */ var _c_msg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @c/msg */ "./hs-libs/components/msg.js");



//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      data: this.value
    };
  },
  props: {
    value: {
      default: ""
    },
    name: {
      default: ""
    },
    readonly: {
      default: false
    },
    validate: {
      default: ""
    },
    url: {
      detaul: ""
    },
    params: {
      default: function _default() {
        return {};
      }
    },
    fileExt: {}
  },
  computed: {
    text: function text() {
      return this.data || "请上传文件";
    }
  },
  watch: {
    value: function value(val) {
      this.data = val;
    },
    data: function data(val) {
      this.$emit("input", val);
    }
  },
  methods: {
    showError: function showError(txt) {
      if (txt) _c_msg__WEBPACK_IMPORTED_MODULE_5__["default"].info(txt, "error");
    },
    upload0: function upload0() {
      if (!this.readonly) this.$file.click();
    },
    upload1: function upload1() {},
    upload2: function upload2(d) {
      // error
      if (!d.status) {
        this.showError(d.message || "访问服务器错误");
      } else {
        this.data = d.name;
      }
    },
    view: function view() {
      if (this.data) {
        window.open("".concat(this.url, "/../").concat(this.data));
      }
    },
    remove: function remove() {
      if (!this.readonly) this.data = "";
    }
  },
  mounted: function mounted() {
    var _this = this;

    this.$file = $(this.$el).find("input[type=file]");
    this.$file.ajaxfileupload({
      action: this.url,
      params: this.params,
      validate_extensions: !!this.fileExt,
      valid_extensions: this.fileExt,
      onStart: function onStart() {
        _c_progress__WEBPACK_IMPORTED_MODULE_4__["default"].show();
      },
      onComplete: function onComplete(d) {
        _this.$file.val("");

        _c_progress__WEBPACK_IMPORTED_MODULE_4__["default"].hide();

        _this.upload2(d);
      }
    });
  }
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js")))

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib/index.js?!./hs-libs/components/ui/FileUpload/Index.vue?vue&type=template&id=28427a22&":
/*!**********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/thread-loader/dist/cjs.js!./node_modules/vue-loader/lib??vue-loader-options!./hs-libs/components/ui/FileUpload/Index.vue?vue&type=template&id=28427a22& ***!
  \**********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/*! all exports used */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "input-group" }, [
    _c("input", {
      directives: [
        {
          name: "model",
          rawName: "v-model",
          value: _vm.text,
          expression: "text"
        },
        {
          name: "validate",
          rawName: "v-validate",
          value: _vm.validate,
          expression: "validate"
        }
      ],
      staticClass: "form-control",
      attrs: { type: "text", readonly: "", name: _vm.name },
      domProps: { value: _vm.text },
      on: {
        input: function($event) {
          if ($event.target.composing) {
            return
          }
          _vm.text = $event.target.value
        }
      }
    }),
    _vm._v(" "),
    _c("input", {
      staticStyle: { display: "none" },
      attrs: { type: "file", name: "file" },
      on: { change: _vm.upload1 }
    }),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "input-group-btn" },
      [
        !!this.value
          ? _c(
              "a",
              {
                staticClass: "btn btn-default",
                on: {
                  click: function($event) {
                    $event.preventDefault()
                    return _vm.view($event)
                  }
                }
              },
              [_c("i", { staticClass: "fa fa-eye" })]
            )
          : _vm._e(),
        _vm._v(" "),
        !_vm.readonly
          ? [
              !!this.value
                ? _c(
                    "a",
                    {
                      staticClass: "btn btn-default",
                      on: {
                        click: function($event) {
                          $event.preventDefault()
                          return _vm.remove($event)
                        }
                      }
                    },
                    [_c("i", { staticClass: "fa fa-times" })]
                  )
                : _vm._e(),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "btn btn-default",
                  on: {
                    click: function($event) {
                      $event.preventDefault()
                      return _vm.upload0($event)
                    }
                  }
                },
                [_c("i", { staticClass: "fa fa-upload" })]
              )
            ]
          : _vm._e()
      ],
      2
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=comps-FileUpload-Index.js.map